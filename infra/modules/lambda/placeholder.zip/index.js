exports.handler = async () => ({
  statusCode: 200,
  body: JSON.stringify({ message: "Placeholder — run the backend deploy workflow to install the real function." }),
});
